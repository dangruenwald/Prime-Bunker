
import Hero from '@/components/Hero'
import ServiceCards from '@/components/ServiceCards'
import MapBlock from '@/components/MapBlock'

export default function Page() {
  return (<>
    <Hero title="Sustainability & Transition Fuels" subtitle="Future fuels without fiction." />
    <ServiceCards />
    <MapBlock />
  </>)
}
