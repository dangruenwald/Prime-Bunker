
import Hero from '@/components/Hero'
import ServiceCards from '@/components/ServiceCards'
import MapBlock from '@/components/MapBlock'

export default function Page() {
  return (<>
    <Hero title="Operational & Logistical Support" subtitle="Operations first. Everything else follows." />
    <ServiceCards />
    <MapBlock />
  </>)
}
