
import Hero from '@/components/Hero'
import ServiceCards from '@/components/ServiceCards'
import MapBlock from '@/components/MapBlock'

export default function Page() {
  return (<>
    <Hero title="Fuel Procurement & Price Risk Management" subtitle="Fixed, floating, and index-linked solutions backed by market intelligence." />
    <ServiceCards />
    <MapBlock />
  </>)
}
