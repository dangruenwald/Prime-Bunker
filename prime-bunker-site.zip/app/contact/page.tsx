
import Hero from '@/components/Hero'

export default function Page() {
  return (<>
    <Hero title="Contact & Enquiry" subtitle="Reach us any time, anywhere." />
    <section className="section my-10">
      <form className="grid md:grid-cols-2 gap-4 card bg-white/80 dark:bg-white/5 p-6" method="post" action="/api/contact">
        {['Name','Company','Email','Phone','Vessel','Port','ETA','Product'].map((label) => (
          <label key={label} className="text-sm">
            <span className="block mb-1">{label}</span>
            <input name={label.toLowerCase()}
              className="w-full rounded-xl border px-3 py-2 bg-white/90 dark:bg-black/20 border-black/10 dark:border-white/10" />
          </label>
        ))}
        <label className="md:col-span-2 text-sm">
          <span className="block mb-1">Notes</span>
          <textarea name="notes" rows={4}
            className="w-full rounded-xl border px-3 py-2 bg-white/90 dark:bg-black/20 border-black/10 dark:border-white/10" />
        </label>
        <div className="md:col-span-2">
          <button className="rounded-xl px-4 py-2 bg-brand-accent text-white">Submit</button>
        </div>
      </form>
    </section>
  </>)
}
