
import Hero from '@/components/Hero'
import ServiceCards from '@/components/ServiceCards'
import MapBlock from '@/components/MapBlock'

export default function Page() {
  return (<>
    <Hero title="Compliance & Quality Assurance" subtitle="Fuel integrity isn’t negotiable — it’s verified." />
    <ServiceCards />
    <MapBlock />
  </>)
}
