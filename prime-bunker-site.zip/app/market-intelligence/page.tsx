
import Hero from '@/components/Hero'
import ServiceCards from '@/components/ServiceCards'
import MapBlock from '@/components/MapBlock'

export default function Page() {
  return (<>
    <Hero title="Market Intelligence & Analysis" subtitle="Numbers tell a story — we help you read it." />
    <ServiceCards />
    <MapBlock />
  </>)
}
