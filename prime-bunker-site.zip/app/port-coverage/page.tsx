
import Hero from '@/components/Hero'
import ServiceCards from '@/components/ServiceCards'
import MapBlock from '@/components/MapBlock'

export default function Page() {
  return (<>
    <Hero title="Port Coverage & Physical Supply Network" subtitle="Wherever the vessel calls, we’re already there." />
    <ServiceCards />
    <MapBlock />
  </>)
}
