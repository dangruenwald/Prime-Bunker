
import './globals.css'
import { ThemeProvider } from '@/components/ThemeProvider'
import Header from '@/components/Header'
import Footer from '@/components/Footer'
import type { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'Prime Bunker Services — Marine Fuel Supply & Bunker Trading',
  description: 'Global coverage across 100+ ports. VLSFO, MGO, HSFO. Compliance-first, operations-led.',
  openGraph: {
    title: 'Prime Bunker Services — Marine Fuel Supply & Bunker Trading',
    description: 'Trusted bunker supply with precision. Day & Night trading modes.',
    images: ['/og-day.jpg']
  },
  metadataBase: new URL('https://prime-bunker.com')
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className="theme-fade bg-brand-dayBG text-brand-dayInk dark:bg-brand-nightBG dark:text-brand-nightInk">
        <ThemeProvider attribute="class" defaultTheme="system" enableSystem>
          <Header />
          <main>{children}</main>
          <Footer />
        </ThemeProvider>
      </body>
    </html>
  )
}
