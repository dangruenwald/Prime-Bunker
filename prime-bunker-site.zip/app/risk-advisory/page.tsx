
import Hero from '@/components/Hero'
import ServiceCards from '@/components/ServiceCards'
import MapBlock from '@/components/MapBlock'

export default function Page() {
  return (<>
    <Hero title="Claims, Disputes & Risk Advisory" subtitle="When things go sideways, we stay upright." />
    <ServiceCards />
    <MapBlock />
  </>)
}
