
import Hero from '@/components/Hero'
import ServiceCards from '@/components/ServiceCards'
import MapBlock from '@/components/MapBlock'

export default function Page() {
  return (<>
    <Hero title="Marine Fuel Supply & Bunker Trading" subtitle="Global coverage — responsive service — trusted supply." />
    <ServiceCards />
    <MapBlock />
  </>)
}
